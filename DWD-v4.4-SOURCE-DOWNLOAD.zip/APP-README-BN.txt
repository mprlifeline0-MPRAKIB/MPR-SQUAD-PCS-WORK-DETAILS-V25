DWD – Daily Work Details | MPR SQUAD™

Release: v4.4
Android applicationId: com.mprlifeline.pcs (unchanged for update compatibility)
versionCode: 44
versionName: 4.4
Launcher label: DWD – Daily Work Details

Branding:
- MPR SQUAD™
- MP RAKIB — Founder & Lead Developer
- Contact: 019090-62744
- Email: mpr.lifeline0@gmail.com

Launcher icon:
- User-provided DWD poster artwork is included in app/src/main/assets/dwd-launcher-original-artwork.png.
- Normal and round launcher icons are included for mdpi, hdpi, xhdpi, xxhdpi and xxxhdpi.

Build:
- Use the dedicated workflow .github/workflows/build-dwd-apk.yml.
- Workflow name: Build DWD Daily Work Details v4.4 APK.
- Successful artifact name: DWD-Daily-Work-Details-v4.4-APK.
- Artifact contains DWD-Daily-Work-Details-v4.4-debug.apk and SHA256SUMS.txt.

Verification honesty:
- Source archive integrity and JavaScript syntax were checked.
- Android APK compilation and device installation have not yet been performed in this environment.
- Do not treat a PCS workflow run as a DWD v4.4 build.
