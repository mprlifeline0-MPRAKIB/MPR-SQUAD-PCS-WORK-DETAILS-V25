# DWD – Daily Work Details | MPR SQUAD™

**Source release:** v4.4  
**Android application ID:** `com.mprlifeline.pcs` (kept unchanged for update compatibility)  
**Version:** `versionCode 44` / `versionName 4.4`  
**Launcher label:** `DWD – Daily Work Details`

## Branding included
- User-supplied DWD poster artwork used for launcher icon assets.
- Normal and round launcher icons in mdpi, hdpi, xhdpi, xxhdpi and xxxhdpi.
- MPR SQUAD™ branding.
- MP RAKIB — Founder & Lead Developer.
- Contact: 019090-62744
- Email: mpr.lifeline0@gmail.com

## GitHub Actions build
1. Keep this DWD project on a dedicated branch named `dwd-v4.4`; do not overwrite the separate PCS app branches/workflows.
2. Extract/upload the contents of this ZIP into the repository root on that branch, preserving `.github/workflows/build-dwd-apk.yml`.
3. Open **Actions** → **Build DWD Daily Work Details v4.4 APK** → **Run workflow**.
4. Wait for the workflow to finish.
5. In that exact successful run, download artifact `DWD-Daily-Work-Details-v4.4-APK`.
6. The artifact contains `DWD-Daily-Work-Details-v4.4-debug.apk` and `SHA256SUMS.txt`.

This workflow verifies project identity, version, package ID, all launcher icon densities and JavaScript syntax. It also fails if the APK is missing, and uploads the APK plus checksum only after the file exists.

## Local build requirements
JDK 17, Android SDK API 35, and Gradle 8.9. Run `gradle --no-daemon clean assembleDebug`.
APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Verification status
- ZIP integrity: checked.
- Launcher assets: present for all five density buckets (normal and round).
- `app.js` syntax: checked.
- `index.html` inline JavaScript syntax: checked.
- Android APK compilation, install and runtime regression testing: not performed in this environment because Gradle/Android SDK are unavailable. A successful GitHub Actions run and a downloadable artifact are still required before claiming the APK is built.
