MPR SQUAD P.C.S WORK DETAILS — v2.9

এই প্যাকেজে দুটি অংশ আছে:
1) index.html — Android Chrome-এ চালানোর অফলাইন ওয়েব অ্যাপ সোর্স।
2) android/ — Android Studio-তে খোলার উপযোগী WebView APK project source।

উন্নতি:
- ডিউটি, বিল, বেতন/মোবাইল বিল/বোনাস এবং অন্যান্য রেকর্ডে ব্যক্তি নির্বাচন (ঐচ্ছিক)
- ডিউটি, বিল, বেতন এবং অন্যান্য রেকর্ডে কাজের স্থান
- PDF রিপোর্টে তারিখ, স্থান ও ব্যক্তি অনুযায়ী সব ক্যাটাগরির রেকর্ড ছাঁকার ব্যবস্থা
- PDF রিপোর্টে ব্যক্তিভিত্তিক খরচের সারাংশ এবং বিলের পরিশোধিত/বকেয়া হিসাব
- Android APK wrapper: WebView local storage, Android Print framework, Downloads-এ JSON/CSV সেভ, JSON file picker
- পুরোনো localStorage key অপরিবর্তিত রাখা হয়েছে: mpr_pcs_work_details_v1

গুরুত্বপূর্ণ সীমাবদ্ধতা:
- YouTube QR যুক্ত করা হয়নি, কারণ আগের কথোপকথনে আসল QR ছবি বা সঠিক YouTube URL পাওয়া যায়নি। আসল QR ছবি অথবা channel URL প্রয়োজন।
- Android Studio project source দেওয়া হয়েছে; এই পরিবেশে Android SDK/Gradle build environment না থাকায় APK compile, signing, install এবং ফোনে পূর্ণ পরীক্ষা করা হয়নি।
- APK তৈরি করতে Android Studio-তে android/ ফোল্ডার খুলে Build > Build APK(s) ব্যবহার করুন, অথবা GitHub Actions workflow চালান।
- পুরোনো অ্যাপ/ডেটা মুছবেন না; আগে JSON backup নিন।


v2.9: Developer Details স্ক্রিনে Facebook, Instagram, TikTok, YouTube, WhatsApp, Telegram, Website বা অন্যান্য প্ল্যাটফর্মের URL ও QR ছবি যোগ/পরিবর্তন/মুছতে পারবেন। প্রথমবার Admin PIN তৈরি করতে হবে। QR ছবি ২ MB-এর কম রাখুন। PIN লোকাল ডেটায় থাকে; এটি সার্ভার-স্তরের নিরাপত্তা নয়।
